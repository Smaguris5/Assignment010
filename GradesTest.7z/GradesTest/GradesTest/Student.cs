﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradesTest
{
    class Student
    {
        
        private GradeProfile student1Profile = new GradeProfile(); // copy from previous

        private string studentId;
        private string fName;
        private string sName;
        private string eAddress;
        private string telNumber;

        public Student()
        {
        }

        public Student(string fn, string sn, string ea, string tn, string si)
        {
            fName = fn;
            sName = sn;
            eAddress = ea;
            telNumber = tn;
            studentId = si;
        }

        public string StudentId
        {
            get { return this.studentId; }
            set { this.studentId = value; }
        }

        public string FirstName
        {
            get { return this.fName; }
            set { this.fName = value; }
        }

        public string SecondName
        {
            get { return this.sName; }
            set { this.sName = value; }
        }

        public string EmailAddress
        {
            get { return this.eAddress; }
            set { this.eAddress = value; }
        }

        public string TelNumber
        {
            get { return this.telNumber; }
            set { this.telNumber = value; }
        }


        //public void addStudent(Student student)
        //{
        //    students.Add(student);
        //}

        //public void showStudents()
        //{
        //    for ( int i=0; i < students.Count; i++ )
        //    {
        //        Console.WriteLine("SID :" + students.ElementAt(i).studentId);
        //        Console.WriteLine("Name: " + students.ElementAt(i).fName + " " + students.ElementAt(i).sName);
        //        Console.WriteLine("Contact Details: " + students.ElementAt(i).eAddress + " , " + students.ElementAt(i).telNumber);

        //    }
        //}

        public void AddGrade(Grade g)
        {
            student1Profile.addGrade(g);
        }

        //public void showStudentGrades()
        //{
        //    int i = 0;
        //    foreach (Grade gradelist in grades)
        //    {
        //        Console.WriteLine(grades.ElementAt(i).Assignment +" "+ grades.ElementAt(i).Module +" "+ grades.ElementAt(i).GRADE);

        //    }
        //}

    }
}
