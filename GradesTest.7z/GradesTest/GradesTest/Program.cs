﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradesTest
{
    class Program
    {


        public static GradeProfile gradeProfiles = new GradeProfile();
        //public static Student students = new Student();

        static void Main(string[] args)
        {
            List<Student> students = new List<Student>(); // stores seperate information about students

            Student student1 = new Student("Oreo", "Sab", "soreosab@gmail.com", "07473167137", "078");
            Student student02 = new Student("Gerda", "Bal", "gerdabal@gmail.com", "075864434887", "079");
            students.Add(student1); // add student to <>students
            students.Add(student02);

            for (int i = 0; i < students.Count; i++)
            {
                Console.WriteLine("SID :" + students.ElementAt(i).StudentId);
                Console.WriteLine("Name: " + students.ElementAt(i).FirstName + " " + students.ElementAt(i).SecondName);
                Console.WriteLine("Contact Details: " + students.ElementAt(i).EmailAddress + " , " + students.ElementAt(i).TelNumber);

            }



            Console.ReadLine();

            Grade grade1 = new Grade("PROG", "01", "41");
            Grade grade2 = new Grade("DB", "01", "68");
            Grade grade3 = new Grade("NET", "01", "80");
            gradeProfiles.addGrade(grade1); // add grade info to <>grades
            gradeProfiles.addGrade(grade2);
            gradeProfiles.addGrade(grade3);

            gradeProfiles.showGrades(); // Shows list of grades

            // SHOW STUDENT AND ITS GRADES/ASSIGNMENTS


            Console.ReadLine();

            //Console.WriteLine(" " + grade1.Assignment); //Works fine but is this the correct way??

            //students.showStudentGrades();

            //Console.ReadLine();
        }
    }
}
