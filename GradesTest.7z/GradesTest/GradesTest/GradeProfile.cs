﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradesTest
{
    class GradeProfile
    {
        private List<Grade> grades = new List<Grade>();  // stores list of grades

        public GradeProfile()
        {
        }

        public void addGrade(Grade g)
        {
            grades.Add(g);
        }

        public void showGrades()
        {
            int i = 0;
            foreach (Grade gradelist in grades)
            {
                Console.WriteLine("Module: " + gradelist.Module + "\nAssignment :" + 
                    gradelist.Assignment + "\nGrade :" + gradelist.GRADE + "\n");

            }
        }

    }
}
