﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradesTest
{
    class Grade
    {
        private string module;
        private string assignment;
        private string grade;

        public Grade()
        {
        }

        public Grade(string m, string a, string g)
        {
            module = m;
            assignment = a;
            grade = g;
        }

        public string Module
        {
            get { return this.module; }
            set { this.module = value; }
        }

        public string Assignment
        {
            get { return this.assignment; }
            set { this.assignment = value; }
        }

        public string GRADE
        {
            get { return this.grade; }
            set { this.grade = value; }
        }
    }

}
